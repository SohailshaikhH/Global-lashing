 <?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>

 <!-- header -->
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <a class="navbar-brand" href="index.php"
          ><img
          src="new-imag/logo.png"
          alt="global lashing LOGO" class="img-fluid"
          /></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarTogglerDemo02"
          aria-controls="navbarTogglerDemo02"
          aria-expanded="false"
          aria-label="Toggle navigation"
          >
        <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse justify-content-end"
          id="navbarTogglerDemo02"
          >
          <div class="wrapper">
            <div class="contact-numbers py-2">
              <a class="contact-numbers" href="mailto:info@globallashingandlifting.com"
                ><img src="new-imag/email.png" class="px-1" alt="" /><span
                >info@globallashingandlifting.com</span
                ></a
                >
              <a class="contact-numbers" href="tel:+919321928016"
                ><img src="new-imag/phone-call.png" class="px-1" alt="" /><span
                >+91-9321928016 | 9892365005</span
                ></a
                >
            </div>
            <div>
              <ul class="navbar-nav py-2">
                
                <li class="nav-item">
                  <a class="nav-link <?php if ($currentPage == 'about-us.php') { echo 'strline'; } ?>" href="about-us.php">About Us</a>
                </li>
				 <li class="nav-item">
                  <a class="nav-link" href="#">Factory</a>
                </li>
               
				<li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Products
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
		  
		    <li><a href="#" class="dropdown-item">One Way Lashing</a>
              </li>
			 <li>
                <a href="#" class="dropdown-item">Ratchet Lashing &raquo;</a>
				
				 <ul class="submenu dropdown-menu">
            <li><a class="dropdown-item" href="#">Tie down</a></li>
            <li><a class="dropdown-item" href="#">Car lashing</a></li>
           
            <li><a class="dropdown-item" href="#">Ratchet Lashing Endless</a></li>
            <li><a class="dropdown-item" href="#">Cam Buckle Endless</a></li>
			<li><a class="dropdown-item" href="#">Velcro Lashing</a></li>
			
          </ul>
				
              </li>
              <li>
                <a href="#" class="dropdown-item">Lifting Slings &raquo;</a>
				
				
				 <ul class="submenu dropdown-menu">
            <li><a class="dropdown-item" href="#">Eye to Eye Slings</a></li>
            <li><a class="dropdown-item" href="#">Flat Endless Slings</a></li>
           
            <li><a class="dropdown-item" href="#">Round Slings</a></li>
            <li><a class="dropdown-item" href="#">Accessories (lifting  slings)</a></li>
			<li><a class="dropdown-item" href="#">D-Shackle</a></li>
			
          </ul>
				
				
				
              </li>
              <li>
                <a href="#" class="dropdown-item">Tools and Accessories &raquo;</a>
				
				<ul class="submenu dropdown-menu">
             <li><a class="dropdown-item" href="#">Manual</a></li>
			 <li><a class="dropdown-item" href="#">Battery Powered</a></li>
			 <li><a class="dropdown-item" href="#">Pneumatic</a></li>
			 <li><a class="dropdown-item" href="#">Accessory(lifting slings)</a></li>
			 <li><a class="dropdown-item" href="#">Accessory(lift - hand palettes)</a></li>
			 <li><a class="dropdown-item" href="#">Dunnage Bags</a></li>
			 <li><a class="dropdown-item" href="#">D-Shackle</a></li>


			
          </ul>
				
              </li>
              <li>
                <a href="#" class="dropdown-item">Hardware &raquo;</a>
				

           <ul class="submenu dropdown-menu">
             <li><a class="dropdown-item" href="#">Ratchet</a></li>
			 <li><a class="dropdown-item" href="#">End Fittings</a></li>
			 <li><a class="dropdown-item" href="#">Buckles</a></li>
          </ul>
				
				
				
              </li>
			  <li><a href="#" class="dropdown-item">Composite Strap</a>
              </li>
              <li><a href="global-packaging.php" class="dropdown-item">Global Packaging</a>
              </li>
              
            
			
          </ul>
        </li>
				
				
				 <li class="nav-item">
                  <a class="nav-link" href="#">Clients</a>
                </li>
				
				
				
				
				
				
					<li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           Gallery
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
		  
		    <li><a href="#" class="dropdown-item">Warehouse </a>
              </li>
			   <li><a href="#" class="dropdown-item">Certificates</a>
              </li>
			 </ul>	
			</li>	
				
				
				
				
				
				
				
                <li class="nav-item">
                  <a class="nav-link" href="/global/blog">Blogs</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link   <?php if ($currentPage == 'contact-us.php') { echo 'strline'; } ?> " href="contact-us.php">Contact Us</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </nav>